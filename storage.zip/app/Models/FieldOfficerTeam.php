<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FieldOfficerTeam extends Model
{
    //
}
