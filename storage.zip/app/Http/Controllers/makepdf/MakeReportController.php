<?php

namespace App\Http\Controllers\makepdf;

use App\Models\User;
use App\Models\SiteSetting;
use App\Models\Invoice;
use App\Models\StockInvoice;
use App\Models\Medicine;
use Redirect,Response;
use PDF;
use Illuminate\Support\Number;
use Carbon\Carbon;  

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MakeReportController extends Controller
{
    /**
    * Display a listing of the resource.
    *
    * @return \Illuminate\Http\Response
    */

    public function __construct(){
        if(auth()->user()->hasRole('Super Admin') || auth()->user()->can('view-report')) {
            return true;
        }else{
            abort(403, 'Unauthorized action.'); 
        }
    }

    public function index()
    {
        $managers = User::where('role', 'Manager')->get();
        return view('make_pdf.report.index', compact('managers'));
    }

    public function dailySalesCollection(Request $request){
        if(!$request->manager_id){        
            $user_data_all = User::where('role', 'Manager')->get();
        }
        if($request->manager_id){
            $user_data_all = User::where('role', 'Zonal Sales Executive')->where('manager_id', $request->manager_id)->get();
            $manager_data = User::where('id', $request->manager_id)->first();
        }

        $site_data = SiteSetting::first();
        $data = [
            'date' => date('m/d/Y'), // Fixed date format
            'pdf_title' => 'Impex Pharma ',
            'pdf_logo' => url($site_data->site_logo),
            'user_data_all' => $user_data_all,
            'start_date' => Carbon::parse($request->start_date),
            'end_date' => Carbon::parse($request->end_date),
            'manager_data' => $manager_data ?? ''
        ];

        $pdf = PDF::loadView('make_pdf.report.daily_collection', $data);
        $pdf->setPaper('a4');
        $pdf->AutoPrint(true);
        return $pdf->stream($site_data->site_invoice_prefix . '-' . $request->invoice . '(' . date('m-d-Y') . ').pdf'); // Fixed string interpolation
    }

    public function stockStatement(Request $request){
        $start_date = Carbon::parse($request->report_date)->startOfMonth()->format('Y-m-d');
        $end_date = Carbon::parse($request->report_date)->format('Y-m-d');
        $report_date = Carbon::parse($request->report_date);
        $medicines = Medicine::all();
        $invoices = Invoice::with('salesMedicines')->whereBetween('invoice_date', [$start_date, $end_date])->get();
        $stock_invoices = StockInvoice::with('stockLists')->whereBetween('invoice_date', [$start_date, $end_date])->get();
        $site_data = SiteSetting::first();
        $data = [
            'date' => date('m/d/Y'), // Fixed date format
            'pdf_title' => 'Impex Pharma ',
            'pdf_logo' => url($site_data->site_logo),
            'medicines' => $medicines,
            'invoices' => $invoices,
            'stock_invoices' => $stock_invoices,
            'report_date' => $report_date,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'manager_data' => $manager_data ?? ''
        ];

        $pdf = PDF::loadView('make_pdf.report.stock-statement', $data);
        $pdf->setPaper('a4');
        $pdf->AutoPrint(true);
        return $pdf->stream($site_data->site_invoice_prefix . '-' . $request->invoice . '(' . date('m-d-Y') . ').pdf'); // Fixed string interpolation
    }

}
