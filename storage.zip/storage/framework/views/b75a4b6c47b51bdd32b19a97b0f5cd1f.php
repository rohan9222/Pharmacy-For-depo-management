<div>
    <div class="row">
        <div class="col-md-12">
            <div class="card border-0 border-r20 mb-3">
                <div class="card-header bg-transparent border-0">
                    <h4 class="card-title">Target History</h4>
                </div>
                <div class="card-body">
                    <div class="row m-1">
                        <!--[if BLOCK]><![endif]--><?php if(auth()->user()->role == 'Super Admin'): ?>
                            <div class="row p-1 mb-1">
                                <div class="col-4">
                                    <select class="form-select form-select-sm" wire:change="updateUserList(); $wire.set('zse_id', null)" wire:model="manager_id">
                                        <option value=''>Select Zonal Sales Executive</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($manager->id); ?>"><?php echo e($manager->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </div>
                                <div class="col-4">
                                    <select class="form-select form-select-sm" wire:change="updateUserList(); $wire.set('tse_id', null)" wire:model="zse_id">
                                        <option value=''>Select Zonal Sales Executive</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $zses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($zse->id); ?>"><?php echo e($zse->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </div>
                                
                            </div>
                        <?php elseif($type == 'manager'): ?>
                            <div class="row p-1 mb-1">
                                <div class="col-4">
                                    <select class="form-select form-select-sm" wire:change="updateUserList(); $wire.set('tse_id', null)" wire:model="zse_id">
                                        <option value=''>Select Zonal Sales Executive</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $zses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($zse->id); ?>"><?php echo e($zse->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </div>
                                
                            </div>
                        <?php elseif($type == 'zse'): ?>
                            <div class="row p-1 mb-1">
                                <div class="col-4">
                                    <select class="form-select form-select-sm" wire:change="updateUserList()" wire:model="tse_id" >
                                        <option value=''>Select Territory Sales Executive</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tses ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tse->id); ?>"><?php echo e($tse->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="row justify-content-end mb-2">
                        <div class="col-3">
                            <input id="search" class="form-control" type="search" wire:model.live="search" placeholder="Search" aria-label="Search By Name">
                        </div>
                    </div>
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>SN</th>
                                <th>User Name</th>
                                <th>User Role</th>
                                <th>Target</th>
                                <th>Target Achieved</th>
                                <th>Target Month</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $admin_targets ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin_target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($admin_target->userData->name); ?></td>
                                    <td><?php echo e($admin_target->userData->role); ?></td>
                                    <td><?php echo e($admin_target->sales_target); ?></td>
                                    <td><?php echo e($admin_target->sales_target_achieve); ?></td>
                                    <td><?php echo e($admin_target->target_month); ?> <?php echo e($admin_target->target_year); ?></td>
                                    <td><?php echo $admin_target->sales_target_achieved >= $admin_target->sales_target ? '<span class="badge text-bg-success">Completed</span>' : '<span class="badge text-bg-warning">Not Completed</span>'; ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/livewire/target-history.blade.php ENDPATH**/ ?>