<div id="sidebar" class="z-3 sidebar shadow-sm d-flex flex-column p-3 bg-body-tertiary">
    
        <!-- Navigation Links -->
    
     
        <a href="/" class="navbar-brand d-flex align-items-center mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <!-- Logo -->
            <?php if (isset($component)) { $__componentOriginaldaff26d4e64b9d6b339909684d09d478 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldaff26d4e64b9d6b339909684d09d478 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-mark','data' => ['class' => 'sidebar-logo w-25']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'sidebar-logo w-25']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldaff26d4e64b9d6b339909684d09d478)): ?>
<?php $attributes = $__attributesOriginaldaff26d4e64b9d6b339909684d09d478; ?>
<?php unset($__attributesOriginaldaff26d4e64b9d6b339909684d09d478); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldaff26d4e64b9d6b339909684d09d478)): ?>
<?php $component = $__componentOriginaldaff26d4e64b9d6b339909684d09d478; ?>
<?php unset($__componentOriginaldaff26d4e64b9d6b339909684d09d478); ?>
<?php endif; ?>
            <span class="sidebar-text fs-4 fst-italic"><span class="text-info">Impex</span> Pharma</span>
        </a>

        <ul class="nav nav-pills flex-column mb-auto">
            <li class="nav-item">
                <a href="<?php echo e(route('dashboard.index')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                    <i class="bi bi-pie-chart-fill me-2"></i>
                    <span class="sidebar-text">Dashboard</span>
                </a>
            </li>

            
            
                <li class="nav-item">
                    <a href="#" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('supporter.list') ? 'active' : ''); ?>" data-bs-toggle="collapse" data-bs-target="#admin-collapse" aria-expanded="false">
                        <i class="bi bi-people me-2"></i>
                        <span class="sidebar-text">Admin Panel Report</span>
                        <i class="bi bi-chevron-down ms-auto toggle-icon sidebar-text"></i>
                    </a>

                    <div class="collapse" id="admin-collapse">
                        <ul class="ms-4 btn-toggle-nav list-unstyled fw-normal pb-1 small">
                            <?php if(Auth::user()->role == 'Manager' || Auth::user()->hasRole('Depo Incharge') || Auth::user()->hasRole('Super Admin') ): ?>
                                <li>
                                    <a href="<?php echo e(route('supporter.list', ['type' => 'manager'])); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('supporter.list') && request('type') === 'manager' ? 'active' : ''); ?>">
                                        <i class="bi bi-caret-right-fill me-2"></i>
                                        <span class="sidebar-text">Managers</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('supporter.list', ['type' => 'zse'])); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('supporter.list') && request('type') === 'zse' ? 'active' : ''); ?>">
                                        <i class="bi bi-caret-right-fill me-2"></i>
                                        <span class="sidebar-text">Zonal Sales Executives</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('supporter.list', ['type' => 'tse'])); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('supporter.list') && request('type') === 'tse' ? 'active' : ''); ?>">
                                        <i class="bi bi-caret-right-fill me-2"></i>
                                        <span class="sidebar-text">Territory Sales Executives</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if(Auth::user()->role == 'Zonal Sales Executive' ): ?>
                                <li>
                                    <a href="<?php echo e(route('supporter.list', ['type' => 'zse'])); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('supporter.list') && request('type') === 'zse' ? 'active' : ''); ?>">
                                        <i class="bi bi-caret-right-fill me-2"></i>
                                        <span class="sidebar-text">Zonal Sales Executives</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('supporter.list', ['type' => 'tse'])); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('supporter.list') && request('type') === 'tse' ? 'active' : ''); ?>">
                                        <i class="bi bi-caret-right-fill me-2"></i>
                                        <span class="sidebar-text">Territory Sales Executives</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if(Auth::user()->role == 'Territory Sales Executive' ): ?>
                                <li>
                                    <a href="<?php echo e(route('supporter.list', ['type' => 'tse'])); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('supporter.list') && request('type') === 'tse' ? 'active' : ''); ?>">
                                        <i class="bi bi-caret-right-fill me-2"></i>
                                        <span class="sidebar-text">Territory Sales Executives</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>
            

            <li class="nav-item">
                <a href="#" class="nav-link link-body-emphasis <?php echo e(in_array(request()->route()->getName(), ['suppliers', 'customers', 'delivery-man']) ? 'active' : ''); ?>" data-bs-toggle="collapse" data-bs-target="#supporter-collapse" aria-expanded="false">
                    <i class="bi bi-people me-2"></i>
                    <span class="sidebar-text">Supporters</span>
                    <i class="bi bi-chevron-down ms-auto toggle-icon sidebar-text"></i>
                </a>

                <div class="collapse" id="supporter-collapse">
                    <ul class="ms-4 btn-toggle-nav list-unstyled fw-normal pb-1 small">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-customer', 'edit-customer'])): ?>
                            <li>
                                <a href="<?php echo e(route('customers')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('customers') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Customers</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-supplier', 'edit-supplier'])): ?>
                            <li>
                                <a href="<?php echo e(route('suppliers')); ?>" class="nav-list nav-link link-body-emphasis <?php echo e(request()->routeIs('suppliers') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Suppliers/Manufacturer</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-delivery-man', 'edit-delivery-man'])): ?>
                            <li>
                                <a href="<?php echo e(route('delivery-man')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('delivery-man') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Delivery Man</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </li>

            
            <li class="nav-item">
                <a href="#" class="nav-link link-body-emphasis <?php echo e(in_array(request()->route()->getName(), ['categories', 'medicines']) ? 'active' : ''); ?>" data-bs-toggle="collapse" data-bs-target="#medicines-collapse" aria-expanded="false">
                    <i class="bi bi-capsule-pill me-2"></i>
                    <span class="sidebar-text">Medicines</span>
                    <i class="bi bi-chevron-down ms-auto toggle-icon sidebar-text"></i>
                </a>

                <div class="collapse" id="medicines-collapse">
                    <ul class="ms-4 btn-toggle-nav list-unstyled fw-normal pb-1 small">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-category', 'edit-category'])): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('categories')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('categories') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Categories</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('pack-size')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('pack-size') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Pack Size</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-medicine', 'edit-medicine', 'view-medicine'])): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('medicines')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('medicines') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Medicine List</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </li>

            
            <li class="nav-item">
                <a href="#" class="nav-link link-body-emphasis <?php echo e(in_array(request()->route()->getName(), ['stock-medicines', 'stock-medicines-list', 'stock-invoice-list']) ? 'active' : ''); ?>" data-bs-toggle="collapse" data-bs-target="#stock-medicines-collapse" aria-expanded="false">
                    <i class="bi bi-prescription2"></i>
                    <span class="sidebar-text">Stock Medicines</span>
                    <i class="bi bi-chevron-down ms-auto toggle-icon sidebar-text"></i>
                </a>

                <div class="collapse" id="stock-medicines-collapse">
                    <ul class="ms-4 btn-toggle-nav list-unstyled fw-normal pb-1 small">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-medicine-stock', 'edit-medicine-stock'])): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('stock-medicines')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('stock-medicines') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Stock IN</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('stock-invoice-list')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('stock-invoice-list') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Stock Invoice List</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view-medicine-stock'])): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('stock-medicines-list')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('stock-medicines-list') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Stock Medicine List</span>
                                </a>
                            </li>
                            
                        <?php endif; ?>
                    </ul>
                </div>
            </li>

            
            <li class="nav-item">
                <a href="#" class="nav-link link-body-emphasis <?php echo e(in_array(request()->route()->getName(), ['sales-medicines', 'sales-medicines-list']) ? 'active' : ''); ?>" data-bs-toggle="collapse" data-bs-target="#sales-medicines-collapse" aria-expanded="false">
                    <i class="bi bi-receipt"></i>
                    <span class="sidebar-text">Sales Medicines</span>
                    <i class="bi bi-chevron-down ms-auto toggle-icon sidebar-text"></i>
                </a>

                <div class="collapse" id="pos-collapse">
                    <ul class="ms-4 btn-toggle-nav list-unstyled fw-normal pb-1 small">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('invoice')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('pos')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('pos') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">New Sales</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('view-invoice')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('sales-medicines-list')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('sales-medicines-list') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Invoice History</span>
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('sales-delivery-history')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('sales-delivery-history') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Delivery List</span>
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('return-medicines-list')); ?>" class="nav-link link-body-emphasis <?php echo e(request()->routeIs('return-medicines-list') ? 'active' : ''); ?>">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Return History</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </li>
    
            <li class="nav-item">
                <a href="#" class="nav-link link-body-emphasis <?php echo e(in_array(request()->route()->getName(), ['target-history', 'due-list', 'collection-list','report.index']) ? 'active' : ''); ?>" data-bs-toggle="collapse" data-bs-target="#report-collapse" aria-expanded="false">
                    <i class="bi bi-graph-up"></i>
                    <span class="sidebar-text">Reports</span>
                    <i class="bi bi-chevron-down ms-auto toggle-icon sidebar-text"></i>
                </a>
                <div class="collapse" id="report-collapse">
                    <ul class="ms-4 btn-toggle-nav list-unstyled fw-normal pb-1 small">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-report')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('target-history')); ?>" class="nav-link link-body-emphasis">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Target History</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('due-list')); ?>" class="nav-link link-body-emphasis">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Due List</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('collection-list')); ?>" class="nav-link link-body-emphasis">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Collection Report</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('report.index')); ?>" class="nav-link link-body-emphasis">
                                    <i class="bi bi-caret-right-fill me-2"></i>
                                    <span class="sidebar-text">Others Report</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </li>

    
            <?php if(Auth::user()->hasRole('Super Admin')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('site-settings')); ?>" class="nav-link link-body-emphasis">
                        <i class="bi bi-gear me-2"></i>
                        <span class="sidebar-text">Site Settings</span>
                    </a>
                </li>
            <?php endif; ?>

            
        </ul>


        <hr>
        <div class="dropdown">
            
            <a href="#" class="d-flex align-items-center link-body-emphasis text-decoration-none">
                <img src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="" width="32" height="32" class="rounded-circle me-2">
                <strong class="sidebar-text"><?php echo e(Auth::user()->name); ?></strong>
            </a>
            
        </div>
    </div>


<?php $__env->startPush('scripts'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function () {
      $(document).ready(function () {
          const sidebar = $('#sidebar');
          const content = $('#content');
          const navbar = $('#navbar');
          const toggleButton = $('#toggleSidebar');
          const storageKey = 'sidebarCollapsed';

          // Restore the state from localStorage
          const isCollapsed = localStorage.getItem(storageKey) === 'true';
          if (isCollapsed) {
              sidebar.addClass('collapsed');
              content.addClass('collapsed');
              navbar.addClass('collapsed');
              toggleButton.find('i').removeClass('bi-arrow-left-square').addClass('bi-arrow-right-square');
          }

          // Toggle sidebar and save state in localStorage
          toggleButton.click(function () {
              let icon = $(this).find('i');

              if (icon.hasClass('bi-arrow-left-square')) {
                  icon.removeClass('bi-arrow-left-square').addClass('bi-arrow-right-square');
                  localStorage.setItem(storageKey, true); // Save collapsed state
              } else {
                  icon.removeClass('bi-arrow-right-square').addClass('bi-arrow-left-square');
                  localStorage.setItem(storageKey, false); // Save expanded state
              }

              // Toggle classes
              sidebar.toggleClass('collapsed');
              content.toggleClass('collapsed');
              navbar.toggleClass('collapsed');
          });
            $('[data-bs-target="#home-collapse"]').on('click', function () {
                    $(this).find('.toggle-icon').toggleClass('bi-chevron-down bi-chevron-up');
            });
        });
  });
</script>

<?php $__env->stopPush(); ?>
<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>