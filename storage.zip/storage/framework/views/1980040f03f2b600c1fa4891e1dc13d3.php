
<nav x-data="{ open: false }" id="navbar" class="shadow-sm main-header navbar navbar-expand navbar-white navbar-light fixed-top">
    <div class="container-fluid">
        <!-- Hamburger Toggle for Mobile View -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navigation Links -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <button id="toggleSidebar" class="btn btn-sm btn-light ms-2"><i class="bi bi-arrow-left-square"></i></button>

            <ul class="navbar-nav ms-auto">
                <!--[if BLOCK]><![endif]--><?php if(Laravel\Jetstream\Jetstream::hasTeamFeatures()): ?>
                    <!-- Teams Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="teamDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(Auth::user()->currentTeam->name); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="teamDropdown">
                            <li class="dropdown-header"><?php echo e(__('Manage Team')); ?></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('teams.show', Auth::user()->currentTeam->id)); ?>"><?php echo e(__('Team Settings')); ?></a></li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', Laravel\Jetstream\Jetstream::newTeamModel())): ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('teams.create')); ?>"><?php echo e(__('Create New Team')); ?></a></li>
                            <?php endif; ?>
                            <!--[if BLOCK]><![endif]--><?php if(Auth::user()->allTeams()->count() > 1): ?>
                                <li><hr class="dropdown-divider"></li>
                                <li class="dropdown-header"><?php echo e(__('Switch Teams')); ?></li>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = Auth::user()->allTeams(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php if (isset($component)) { $__componentOriginal12b9baaa9d085739b53a541d2c8778fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal12b9baaa9d085739b53a541d2c8778fa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.switchable-team','data' => ['team' => $team]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('switchable-team'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['team' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($team)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal12b9baaa9d085739b53a541d2c8778fa)): ?>
<?php $attributes = $__attributesOriginal12b9baaa9d085739b53a541d2c8778fa; ?>
<?php unset($__attributesOriginal12b9baaa9d085739b53a541d2c8778fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal12b9baaa9d085739b53a541d2c8778fa)): ?>
<?php $component = $__componentOriginal12b9baaa9d085739b53a541d2c8778fa; ?>
<?php unset($__componentOriginal12b9baaa9d085739b53a541d2c8778fa); ?>
<?php endif; ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </li>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <!-- Profile Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <!--[if BLOCK]><![endif]--><?php if(Laravel\Jetstream\Jetstream::managesProfilePhotos()): ?>
                            <img src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="<?php echo e(Auth::user()->name); ?>" class="rounded-circle" width="30" height="30">
                        <?php else: ?>
                            <?php echo e(Auth::user()->name); ?>

                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <li class="dropdown-header"><?php echo e(__('Manage Account')); ?></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>"><?php echo e(__('Profile')); ?></a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-role', 'edit-role', 'delete-role'])): ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('roles.index')); ?>"><?php echo e(__('Manage Role')); ?></a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create-user', 'edit-user', 'delete-user'])): ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('users.index')); ?>"><?php echo e(__('Manage User')); ?></a></li>
                        <?php endif; ?>
                        <!--[if BLOCK]><![endif]--><?php if(Laravel\Jetstream\Jetstream::hasApiFeatures()): ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('api-tokens.index')); ?>"><?php echo e(__('API Tokens')); ?></a></li>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item"><?php echo e(__('Log Out')); ?></button>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/navigation-menu.blade.php ENDPATH**/ ?>