<div class="row">
    <div class="col">
        <div class="" id="multiCollapseExample2">
            <div class="card card-body" style="position: unset;">
                <div class="row">
                    <div class="col-12 mb-2">
                        <h3 class="text-center">Collection Report</h3>
                    </div>
                    <div class="col-12">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user-data-manage', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-217734432-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
                <div class="row mt-3" wire:ignore>
                    <table class="table" id="invoiceTable">
                        <thead>
                            <tr>
                                <th></th>
                                <th>SN</th>
                                <th>Invoice NO</th>
                                <th>Invoice Date</th>
                                <th>Customer ID</th>
                                <th>Customer Name</th>
                                <th>Customer Mobile</th>
                                <th>Total</th>
                                <th>Paid List</th>
                                <th>Total Paid</th>
                                <th>Due</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var table = $('#invoiceTable').DataTable({
            processing: true,
            serverSide: true,
            order: [[ 1, 'desc' ]],
            ajax: {
                url: "<?php echo e(route('collection-list-table')); ?>", // Ensure correct route
                data: function(d) {
                    d.manager_id = $('#manager_id').val();
                    d.zse_id = $('#zse_id').val();
                    d.tse_id = $('#tse_id').val();
                    d.customer_id = $('#customer_id').val();
                    d.start_date = $('#start_date').val();
                    d.end_date = $('#end_date').val();
                }
            },
            columns: [
                { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                { data: 'DT_RowIndex', name: 'DT_RowIndex' },
                { data: 'invoice_no', name: 'invoice_no' },
                { data: 'invoice_date', name: 'invoice_date' },
                { data: 'customer.user_id', name: 'customer.user_id' },
                { data: 'customer.name', name: 'customer.name' },
                { data: 'customer.mobile', name: 'customer.mobile' },
                { data: 'grand_total', name: 'grand_total' },
                {
                    data: 'payment_history',
                    name: 'payment_history',
                    render: function(data) {
                        if (data) {
                            return data.split('<br>').map(entry => `<span class="bg-info">${entry}</span>`).join('<br>');
                        }
                        return 'No Payments';
                    }
                },
                { data: 'paid', name: 'paid' },
                { data: 'due', name: 'due' },
            ],
            columnDefs: [
                {
                    targets: [3],  // Invoice Date and Delivery Date
                    render: function(data, type, row) {
                        return moment(data).format('D-MMM-YYYY');  // Format date
                    }
                },
                {
                    orderable: false,
                    render: DataTable.render.select(),
                    targets: 0
                }
            ],
            dom: 'Bfrtip',
            buttons: [
                'pageLength',
                'colvis',
                'pdf',
                'print'
            ],
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'All']],
            pageLength: 10,
            select: {
                style: 'os',
                selector: 'td:first-child'
            }
        });

        // Reload table on click of the search button
        $('#search, .closeModal').click(function () {
            table.ajax.reload();
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/livewire/collection-report.blade.php ENDPATH**/ ?>