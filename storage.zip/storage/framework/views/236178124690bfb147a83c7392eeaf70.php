<a href="/">
    
    <img class="w-100" src="<?php echo e(asset('img/logo.png')); ?>" alt="">
</a>
<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>