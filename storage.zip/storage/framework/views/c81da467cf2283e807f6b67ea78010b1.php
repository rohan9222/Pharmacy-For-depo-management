<div>
    <form wire:submit.prevent="submit">
        <div class="row g-2">
            <div class="col-4">
                <label for="invoice_date" class="form-label">Date</label>
                <input type="date" class="form-control" wire:model.live.debounce.1000ms="invoice_date">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['invoice_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="col-4">
                <label for="invoice_no" class="form-label">Invoice No</label>
                <input type="text" class="form-control" wire:model.live.debounce.1000ms="invoice_no" readonly>
            </div>
            <div class="col-4">
                <label for="manufacturer" class="form-label">Manufacturer / Supplier</label>
                <select class="form-select" wire:model="manufacturer">
                    <option value="">Select Manufacturer</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['manufacturer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="col-md-12" wire:ignore.self>
                <input
                    type="search"
                    name="medicine_list"
                    class="form-control w-100"
                    placeholder="Search Medicine Name"
                    wire:model.live.debounce.1000ms="medicine_list"
                    wire:focus="fetchMedicines"
                    wire:blur="clearMedicines"
                    autocomplete="off"
                    tabindex="1"
                    wire:keydown.arrow-down="incrementHighlight"
                    wire:keydown.arrow-up="decrementHighlight"
                    wire:keydown.enter="selectHighlightedMedicine"
                    id="medicine_list"
                >
                <!--[if BLOCK]><![endif]--><?php if(!empty($medicines)): ?>
                    <div class="card">
                        <ul class="nav nav-pills flex-column mb-auto">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li
                                    wire:click="addMedicine('<?php echo e($medicine->id); ?>')"
                                    class="w-100 nav-item <?php echo e($index === $highlightedIndex ? 'active' : ''); ?>"
                                    style="cursor: pointer;"
                                    wire:key="medicine-<?php echo e($medicine->id); ?>"
                                >
                                    <span class="nav-link text-dark row">
                                        <div class="d-flex">
                                            <span class="me-1" style="max-width: 50px; max-height: 50px;">
                                                <img class="w-100 h-100 img-fluid img-thumbnail" src="<?php echo e(asset($medicine->image_url ?? 'img/medicine-logo.png')); ?>" alt="">
                                            </span>
                                            <span class="lh-sm fw-medium text-nowrap" title="<?php echo e($medicine->name); ?>">
                                                <span class="text-uppercase fw-bold"><?php echo e($medicine->name); ?> (<span style="color: rgb(177, 55, 181)"><?php echo e($medicine->supplier_price); ?> ৳</span>)</span>
                                                <span class="d-block text-muted" style="font-size: 13px;">Generic name: <?php echo e($medicine->generic_name); ?></span>
                                                <span class="d-block text-muted" style="font-size: 13px;">Manufacturers: <?php echo e($medicine->supplier); ?></span>
                                            </span>
                                        </div>
                                    </span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['medicine_list'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="table-responsive row mt-3">
            <table class="table table-bordered table-sm">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th>Medicine</th>
                        <th>Batch</th>
                        <th>Expiry Date</th>
                        <th>Quantity</th>
                        <th>MRP/Buying Price</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $stockMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <input type="hidden" wire:model.live.debounce.1000ms="stockMedicines.<?php echo e($index); ?>.medicine_id">
                                <img src="<?php echo e(asset($medicine['medicine_image'] ?? 'img/medicine-logo.png')); ?>" alt="" width="50">
                                <?php echo e($medicine['medicine_name']); ?>

                            </td>
                            <td>
                                <input type="text" class="form-control" wire:model.live.debounce.1000ms="stockMedicines.<?php echo e($index); ?>.batch">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["stockMedicines.{$index}.batch"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                            <td>
                                <input type="date" class="form-control" wire:model.live.debounce.1000ms="stockMedicines.<?php echo e($index); ?>.expiry_date">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["stockMedicines.{$index}.expiry_date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                            <td>
                                <input type="number" class="form-control" wire:model.live.debounce.1000ms="stockMedicines.<?php echo e($index); ?>.quantity">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["stockMedicines.{$index}.quantity"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                            <td>
                                <input type="text" class="form-control" wire:model.live.debounce.1000ms="stockMedicines.<?php echo e($index); ?>.buy_price" >
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["stockMedicines.{$index}.buy_price"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                            <td><input type="text" class="form-control" wire:model.live.debounce.1000ms="stockMedicines.<?php echo e($index); ?>.total" readonly></td>
                            <td><button type="button" class="btn btn-sm btn-outline-danger" wire:click="removeMedicine(<?php echo e($index); ?>)"><i class="bi bi-x"></i></button></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="8" class="text-center">
                            <b>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['stockMedicines'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </b>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <hr>
        <div class="row d-flex justify-content-end">
            <div class="col-4">
                <table class="table table-sm">
                    <tr>
                        <th>Sub Total</th>
                        <th>:</th>
                        <td><?php echo e($total); ?> ৳</td>
                    </tr>
                    <tr>
                        <th>Discount</th>
                        <th>:</th>
                        <td>
                            <div class="input-group w-75 ">
                                <input type="text" placeholder="Discount Price" class="form-control form-control-sm" wire:model.live.debounce.1000ms="discount" >
                                <span class="input-group-text bg-info bg-opacity-10">৳</span>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                    <tr>
                        <th>Grand Total</th>
                        <th>:</th>
                        <td><?php echo e($grand_total); ?></td>
                    </tr>
                    <tr>
                        <th>Paid Amount</th>
                        <th>:</th>
                        <td>
                            <div class="input-group w-75">
                                <input type="text" placeholder="Paid Amount" class="form-control form-control-sm" wire:model.live.debounce.1000ms="paid_amount">
                                <span class="input-group-text bg-info bg-opacity-10">৳</span>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                    <tr>
                        <th>Total Due</th>
                        <th>:</th>
                        <td><?php echo e($due_amount); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-12">
                <button type="submit" class="btn btn-primary float-end">Save</button>
            </div>
        </div>
    </form>
</div>

<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/livewire/stock-medicines.blade.php ENDPATH**/ ?>