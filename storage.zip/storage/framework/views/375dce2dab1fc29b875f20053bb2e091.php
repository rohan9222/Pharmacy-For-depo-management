<div class="row">
    <div class="col-md-5 card z-2">
        <div class="row px-4 py-1 slick-category" wire:ignore>
            <div class="btn btn-outline-success btn-sm" wire:click="medicinesCategory(null)" >All</div>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $category_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="btn btn-outline-success btn-sm" wire:click="medicinesCategory('<?php echo e($category_list->name); ?>')" ><?php echo e($category_list->name); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        

        <div class="row px-4 py-1">
            <div class="col-12">
                <input id="search" class="form-control from-control-sm" type="search" wire:model.live="search" placeholder="Search By Name" aria-label="Search By Name">
            </div>
            <div class="col-12 mt-1">
                <?php echo e($category == '' ?  'All' : $category); ?> Medicines List (<?php echo e(count($medicines)); ?>)
            </div>
        </div>

        <div class="row g-1 nav">
            <!--[if BLOCK]><![endif]--><?php if(!empty($medicines)): ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <div class="col-lg-2 col-lg-3 col-md-4 col-6 col-xl-2">
                        <div wire:click="addMedicine('<?php echo e($medicine->id); ?>')" class="p-1 w-100 nav-item btn border border-0 <?php echo e($medicine->quantity > 0 ? '' : 'disabled'); ?>" style="cursor: pointer;" wire:key="medicine-<?php echo e($medicine->id); ?>">
                            <div class="card shadow-sm position-relative nav-link p-0">
                                <div class="position-relative p-1">
                                    <div class="card-header p-2">
                                        <div class="d-flex align-items-center justify-content-center d-block w-100" style="height: 75px;">
                                            <img class="w-100 h-100 img-fluid img-thumbnail" src="<?php echo e(asset($medicine->image_url ?? 'img/medicine-logo.png')); ?>" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="position-relative p-0">
                                    <div class="card-body p-1 text-center">
                                        <h6 class="fs-6 text-dark m-0">
                                            <?php echo e($medicine->name); ?>

                                        </h6>
                                        
                                    </div>
                                </div>
                                <!--[if BLOCK]><![endif]--><?php if($medicine->quantity > 0): ?>
                                    <span class="position-absolute top-0 end-0 badge bg-primary text-white m-1">
                                        QTY: <?php echo e($medicine->quantity); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="position-absolute top-0 end-0 badge bg-danger text-white m-1">
                                        Out of Stock
                                    </span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['medicine_list'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <div class="col-md-7 card">
        <form wire:submit.prevent="submit">
            <div class="row g-2">
                <div class="col-4">
                    <label for="invoice_date" class="form-label">Date</label>
                    <input type="date" class="form-control" wire:model.live.debounce.1000ms="invoice_date">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['invoice_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                
                <div class="col-6">
                    <label for="customer" class="form-label">Customer</label>
                    <div class="input-group mb-3">
                        <select class="form-select tom-select p-0" wire:model.live.debounce.1000ms="customer" x-init="initTomSelect()">
                            <option value="">Select Customer</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->user_id); ?>-<?php echo e($customer->name); ?> (<?php echo e($customer->mobile); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <span class="input-group-text" wire:click="refreshCustomer()"><i class="bi bi-arrow-counterclockwise"></i></span>
                        <span class="input-group-text"><a class="text-info" data-bs-toggle="modal" data-bs-target="#addCustomer">
                            <i class="bi bi-person-plus-fill"></i>
                        </a></span>
                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <div class="table-responsive row mt-3 p-2">
                <table class="table table-bordered table-sm">
                    <thead>
                        <tr class="text-center">
                            <th>SN</th>
                            <th>Medicine</th>
                            <th>Category</th>
                            <th>Quantity</th>
                            <th>MRP/Selling Price</th>
                            <th>Sub Total</th>
                            <th>Vat (%)</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $stockMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($index + 1); ?></td>
                                <td class="text-start">
                                    <input type="hidden" wire:model.live.debounce.1000ms="stockMedicines.<?php echo e($index); ?>.medicine_id">
                                    <?php echo e($medicine['medicine_name']); ?>

                                </td>
                                <td class="text-start"><?php echo e($medicine['category_name']); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a class="btn btn-sm btn-outline-danger" wire:click="decreaseQuantity(<?php echo e($index); ?>)"><i class="bi bi-dash-lg"></i></a>
                                        <input type="number" class="form-control form-control-sm  text-center p-0" wire:model.live.debounce.1000ms="stockMedicines.<?php echo e($index); ?>.quantity">
                                        <a class="btn btn-sm btn-outline-success" wire:click="increaseQuantity(<?php echo e($index); ?>)"><i class="bi bi-plus-lg"></i></a>
                                    </div>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["stockMedicines.{$index}.quantity"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    
                                    <span><?php echo e($stockMedicines[$index]['price']); ?></span>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["stockMedicines.{$index}.price"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    
                                    <span><?php echo e($stockMedicines[$index]['sub_total']); ?></span>
                                </td>
                                <td>
                                    
                                    <span><?php echo e($stockMedicines[$index]['vat']); ?></span>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["stockMedicines.{$index}.vat"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    
                                    <span><?php echo e($stockMedicines[$index]['total']); ?></span>
                                </td>
                                <td><button type="button" class="btn btn-sm btn-outline-danger" wire:click="removeMedicine(<?php echo e($index); ?>)"><i class="bi bi-x"></i></button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="8" class="text-center">
                                <b>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['stockMedicines'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </b>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <hr>
            <div class="row d-flex justify-content-end">
                <div class="col-5">
                    <table class="table table-sm">
                        <tr>
                            <th>Sub Total</th>
                            <th>:</th>
                            <td><?php echo e($sub_total); ?> ৳</td>
                        </tr>
                        <tr>
                            <th>Vat(%)</th>
                            <th>:</th>
                            <td><?php echo e($vat); ?> ৳</td>
                        </tr>
                        <tr>
                            <th>Total</th>
                            <th>:</th>
                            <td><?php echo e($total); ?> ৳</td>
                        </tr>
                        <tr>
                            <th>Discount(%)</th>
                            <th>:</th>
                            <td>
                                <div class="input-group w-75 ">
                                    
                                    <input type="text" placeholder="Spacial Discount Price" class="form-control form-control-sm" value="<?php echo e($discount); ?>" disabled readonly>
                                    <span class="input-group-text bg-info bg-opacity-10"><?php echo e($discount_amount); ?>৳</span>
                                </div>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                        </tr>
                        <tr>
                            <th>Spacial Discount (%)</th>
                            <th>:</th>
                            <td>
                                <div class="input-group w-75 ">
                                    <input type="text" placeholder="Spacial Discount Price" class="form-control form-control-sm" wire:model.live.debounce.1000ms="spl_discount" >
                                    <span class="input-group-text bg-info bg-opacity-10"><?php echo e($spl_discount_amount); ?>৳</span>
                                </div>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['spl_discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                        </tr>
                        <tr>
                            <th>Grand Total</th>
                            <th>:</th>
                            <td><?php echo e($grand_total); ?></td>
                        </tr>
                        <tr>
                            <th>Paid Amount</th>
                            <th>:</th>
                            <td>
                                <div class="input-group w-75">
                                    <input type="text" placeholder="Paid Amount" class="form-control form-control-sm" wire:model.live.debounce.1000ms="paid_amount">
                                    <span class="input-group-text bg-info bg-opacity-10">৳</span>
                                </div>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                        </tr>
                        <tr>
                            <th>Total Due</th>
                            <th>:</th>
                            <td><?php echo e($due_amount); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-12">
                    <button type="submit" class="btn btn-primary float-end">Save</button>
                </div>
            </div>
        </form>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="addCustomer" tabindex="-1" aria-labelledby="addCustomerLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h1 class="modal-title fs-5" id="addCustomerLabel">Modal title</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form wire:submit.prevent="customerSubmit">
                    <div class="row g-2">
                        <div class="col-3">
                            <input class="form-control" type="text" id="name" wire:model="name" placeholder="customer Name" aria-label="customer Name">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-3">
                            <input class="form-control" type="text" id="email" wire:model="email" placeholder="Email Address" aria-label="Email Address">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-3">
                            <input class="form-control" type="text" id="mobile" wire:model="mobile" placeholder="mobile" aria-label="mobile">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-3">
                            <input class="form-control" type="address" id="address" wire:model="address" placeholder="address" aria-label="address">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-3">
                            <input class="form-control" type="number" id="balance" wire:model="balance" placeholder="Balance" aria-label="Balance">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-3">
                            <select name="tse_team" id="tse_team" class="form-control" wire:model="tse_team">
                                <option value="">Select Territory Sales Executive</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tse->id); ?>"
                                        <?php echo e(isset($tse->fieldOfficer) && $tse->fieldOfficer->id == $tse->id
                                            ? 'selected'
                                            : ($tse->id == auth()->user()->id ? 'selected' : '')); ?>>
                                        <?php echo e($tse->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tse_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-3">
                            <input type="text" class="form-control" id="route" wire:model="route" placeholder="Route" aria-label="Route">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['route'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="col-3">
                            <select name="customer_category" id="customer_category" wire:model="customer_category" class="form-control">
                                <option value="">Select Category</option>
                                <option value="Institution">Institution</option>
                                <option value="General">General</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['customer_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <button class="btn btn-primary mt-2" type="submit">Submit</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->startPush('styles'); ?>
    <style>
        .slick-slide{
            padding: 1px;
        }
        .slick-prev {
            left: -3px !important;
        }
        .slick-next {
            right: -3px !important;
        }
        .slick-prev, .slick-next {
            color: black !important;
            background: black !important;
            border: 1px solid black;
            border-radius: 50%;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            $('.slick-category').slick({
                infinite: true,
                slidesToShow: 6,
                slidesToScroll: 1
            });
        });
    </script>
<?php $__env->stopPush(); ?>


<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/livewire/sales-invoice.blade.php ENDPATH**/ ?>