


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(url('css/pdf.css')); ?>" rel="stylesheet" />
    <style>
        @page {
            size: A4 portrait;
            margin: 1cm;
        }

        .footer {
            margin-top: 10rem; ;
        }

        @media print {
            .hide-on-print {
                display: none !important;
            }
        }
        .btn-info {
            background-color: #999;
            color: #FFF;
        }

        .btn-primary {
            background-color: #271db9;
            color: #FFF;
        }

        .btn {
            padding: 10px 20px;
            text-decoration: none;
            border: none;
            display: block;
            text-align: center;
            margin: 7px;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <div class="hide-on-print" style="text-align: center; width: 10%; margin: auto;">
        <table class="table">
            <tbody>
                <tr>
                    <td><a href="<?php echo e(route('pos')); ?>" class="btn btn-info">Back</a> </td>
                    <td><button onclick="window.print();" class="btn btn-primary p-1">Print</button></td>
                </tr>
            </tbody>
        </table>
        <br>
    </div>

    <div class="a4">
        <div class="p-1">
            <div>
                <div style="display: inline-block; width: 45%; float: left;">
                    <p class="m-0 subtitle ">Sales Office :</p>
                    <p class="m-0">Address : <?php echo e($site_data->site_address); ?></p>
                    <p class="m-0">Mobile : <?php echo e($site_data->site_phone); ?></p>
                </div>
                <div class="title">Invoice</div>
            </div>
            
            <table class="table border">
                <tr>
                    <td >Cust ID: <?php echo e($invoice_data->customer->user_id); ?></td>
                    <td >MPO ID: <?php echo e($invoice_data->fieldOfficer->user_id); ?></td>
                    <td>Category: <?php echo e($invoice_data->customer->category); ?></td>
                </tr>
                <tr>
                    <td>Name: <?php echo e($invoice_data->customer->name); ?></td>
                    <td>Name: <?php echo e($invoice_data->fieldOfficer->name); ?></td>
                    <td>Invoice No: <?php echo e($invoice_data->invoice_no); ?></td>
                </tr>
                <tr>
                    <td>Address: <?php echo e($invoice_data->customer->address); ?></td>
                    <td>Mobile: <?php echo e($invoice_data->fieldOfficer->mobile); ?></td>
                    <td>Invoice Date: <?php echo e(date('d-M-Y', strtotime($invoice_data->created_at))); ?></td>
                </tr>
                <tr>
                    <td>Mobile: <?php echo e($invoice_data->customer->mobile); ?></td>
                    <td>Route: <?php echo e($invoice_data->customer->route); ?></td>
                    <td>Delivery Date: <?php echo e(date('d-M-Y', strtotime($invoice_data->delivery_date))); ?></td>
                </tr>
            </table>

            <table class="items text-center">
                <tr class="border">
                    <th class="border-start">Product Name</th>
                    <th class="border-start">Pack Size</th>
                    <th class="border-start">Unit TP</th>
                    <th class="border-start">Unit VAT</th>
                    <th class="border-start">QTY</th>
                    <th class="border-start">Total TP</th>
                    <th class="border-start">Total Vat</th>
                    <th class="border-start border-end">Total Price</th>
                </tr>
            <?php
                $sumTotalPrice = 0;
                $sumVatAmount = 0;
                $sumTotal = 0;
            ?>

            <?php $__currentLoopData = $invoice_data->salesMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $totalPrice = $medicine_list->price * $medicine_list->initial_quantity;
                    $vatAmount = round($totalPrice * $medicine_list->vat / 100, 2);
                ?>
                <tr>
                    <td class="text-start border-dotted border-start"><?php echo e($medicine_list->medicine->name); ?></td>
                    <td class="border-dotted border-start"><?php echo e($medicine_list->medicine->pack_size); ?></td>
                    <td class="border-dotted border-start"><?php echo e($medicine_list->price); ?></td>
                    <td class="border-dotted border-start"><?php echo e($medicine_list->vat); ?></td>
                    <td class="border-dotted border-start"><?php echo e($medicine_list->initial_quantity); ?></td>
                    <td class="border-dotted border-start"><?php echo e($totalPrice); ?></td>
                    <td class="border-dotted border-start"><?php echo e($vatAmount); ?></td>
                    <td class="border-dotted border-start border-end"><?php echo e($medicine_list->total); ?></td>
                </tr>

                <?php
                    $sumTotalPrice += $totalPrice;
                    $sumVatAmount += $vatAmount;
                    $sumTotal += $medicine_list->total;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Total Row -->
                <tr>
                    <td class="text-start" colspan="5">Note:</td>
                    <td class="border-start"><?php echo e($sumTotalPrice); ?></td>
                    <td class="border-start"><?php echo e($sumVatAmount); ?></td>
                    <td class="border-start border-end"><?php echo e($sumTotal); ?></td>
                </tr>

                <tr></tr>
                <tr>
                    <td colspan="5"></td>
                    <td class="border" colspan="2">Discount on TP (<?php echo e($invoice_data->discount+$invoice_data->spl_discount); ?>%):</td>
                    <td class="border"><?php echo e($invoice_data->dis_amount+$invoice_data->spl_dis_amount); ?></td>
                </tr>
                <tr>
                    <td colspan="5" class="subtitle text-uppercase">IN WORD: taka. <?php echo e($grand_total_words); ?> only</td>
                    <td class="border" colspan="2"><b>Net Payable Amount:</b></td>
                    <td class="border"><b><?php echo e($invoice_data->grand_total); ?></b></td>
                </tr>
            </table>
        </div>

        <div class='footer text-center' style='width:100%;'>
            <div style='width:20%; float: left;'>
                <p>-------------------</p>
                <p>Powered By</p>
            </div>
            <div style='width:20%; float: left;'>
                <p>-------------------</p>
                <p>Authorized By</p>
            </div>
            <div style='width:20%; float: left;'>
                <p>-------------------</p>
                <p>Delivered By</p>
            </div>
            <div style='width:20%; float: left;'>
                <p>-------------------</p>
                <p>Collected By</p>
            </div>
            <div style='width:20%; float: left;'>
                <p>-------------------</p>
                <p>Customer's Signature</p>
            </div>
        </div>
        
    </div>
</body>
<script>
    window.print();
</script>
</html>


<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/make_pdf/invoice-print.blade.php ENDPATH**/ ?>