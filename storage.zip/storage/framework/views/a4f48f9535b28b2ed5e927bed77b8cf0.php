
<img <?php echo e($attributes); ?> src="<?php echo e(asset('img/logo.png')); ?>" alt="">
<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/components/application-mark.blade.php ENDPATH**/ ?>