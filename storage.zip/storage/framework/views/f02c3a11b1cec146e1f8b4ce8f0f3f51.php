<div x-data="{ isTableData: true, isInvoiceData: false  }">
    <div x-show="isTableData" x-transition x-cloak>
        <div class="row">
            <div class="col">
                <div class="collapse multi-collapse show" id="multiCollapseExample2">
                    <div class="card card-body" style="position: unset;">
                        <div class="row mt-3">
                            <div class="row justify-content-end">
                                <div class="col m-1 p-1">
                                    <h3 class="text-center">
                                        All Medicine Stock List with Invoice NO
                                    </h3>
                                </div>
                                <div class="col-3">
                                    <input id="search" class="form-control" type="search" wire:model.live="search" placeholder="Search" aria-label="Search By Name">
                                </div>
                            </div>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>SN</th>
                                        <th>Invoice NO</th>
                                        <th>Invoice Date</th>
                                        <th>Total</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $stock_invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock_invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($stock_invoice->invoice_no); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($stock_invoice->invoice_date)->format('d M Y')); ?></td>
                                            <td><?php echo e($stock_invoice->total); ?></td>
                                            <td><?php echo e($stock_invoice->paid); ?></td>
                                            <td><?php echo e($stock_invoice->due); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-info" wire:click="invoiceView(<?php echo e($stock_invoice->id); ?>)" @click="isTableData = false, isInvoiceData = true">view invoice</button>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('return-medicine')): ?>
                                                    <button class="btn btn-sm btn-warning" wire:click="returnStockMedicine(<?php echo e($stock_invoice->id); ?>)" @click="isTableData = false, isInvoiceData = true"><i class="bi bi-arrow-counterclockwise"></i></button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>

                            <?php echo e($stock_invoices->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div x-show="isInvoiceData" x-transition x-cloak>
        <button class="btn btn-sm btn-info mb-1" wire:click="invoiceView()" @click="isTableData = true, isInvoiceData = false">back</button>
        <!--[if BLOCK]><![endif]--><?php if($stock_invoice_data): ?>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="invoice-title">
                                    <h4 class="float-end font-size-15">Invoice #<?php echo e($stock_invoice_data->invoice_no); ?>  <span class="badge bg-<?php echo e($stock_invoice_data->paid >= $stock_invoice_data->grand_total ? 'success' : 'danger'); ?> font-size-12 ms-2"><?php echo e($stock_invoice_data->paid >= $stock_invoice_data->grand_total ? 'Paid' : 'Unpaid'); ?></span></h4>
                                    <div class="mb-4">
                                        <h2 class="mb-1 text-muted"><?php echo e(url('/')); ?></h2>
                                    </div>
                                    
                                </div>

                                <hr class="my-4">

                                <div class="row">
                                    
                                    <!-- end col -->
                                    <div class="col-12 justify-end">
                                        <div class="text-muted text-sm-end">
                                            <div>
                                                <h5 class="font-size-15 mb-1">Invoice No: #<?php echo e($stock_invoice_data->invoice_no); ?></h5>
                                            </div>
                                            <div class="mt-4">
                                                <h5 class="font-size-15 mb-1">Invoice Date:  <?php echo e(\Carbon\Carbon::parse($stock_invoice_data->invoice_date)->format('d M Y')); ?></h5>
                                            </div>
                                            <div class="mt-4">
                                                <h5 class="font-size-15 mb-1">Create Time: <?php echo e(\Carbon\Carbon::parse($stock_invoice_data->created_at)->format('d M Y h:i A')); ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end col -->
                                </div>
                                <!-- end row -->

                                <div class="py-2">
                                    <h5 class="font-size-15">Order Summary</h5>

                                    <div class="table-responsive">
                                        <table class="table align-middle table-nowrap table-centered mb-0">
                                            <thead>
                                                <tr class="text-center">
                                                    <th>SN</th>
                                                    <th colspan="2">Medicine</th>
                                                    <th>Batch</th>
                                                    <th>Expiry Date</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                    <th class="text-end">Total</th>
                                                </tr>
                                            </thead><!-- end thead -->
                                            <tbody>
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $stock_invoice_data->stockLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $medicine_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="text-center">
                                                        <td><?php echo e($index + 1); ?></td>
                                                        <td class="text-end">
                                                            <img src="<?php echo e(asset($medicine_list->medicine->image_url ?? 'img/medicine-logo.png')); ?>" alt="" width="50">
                                                        </td>
                                                        <td class="text-start">
                                                            <div>
                                                                <h5 class="text-truncate font-size-14 mb-1"><?php echo e($medicine_list->medicine->name); ?></h5>
                                                                <p class="text-muted mb-0"><?php echo e($medicine_list->medicine->generic_name); ?></p>
                                                                <p class="text-muted mb-0"><?php echo e($medicine_list->medicine->category_name); ?></p>
                                                            </div>
                                                        </td>
                                                        <td><?php echo e($medicine_list->batch_number); ?></td>
                                                        <td>
                                                            <?php echo e(\Carbon\Carbon::parse($medicine_list->expiry_date)->format('d M Y')); ?>

                                                        </td>
                                                        <td><?php echo e($medicine_list->quantity); ?></td>
                                                        <td class="text-center"><?php echo e($medicine_list->buy_price); ?></td>
                                                        <td class="text-end"><?php echo e($medicine_list->quantity * $medicine_list->buy_price); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                <!-- end tr -->
                                                <tr>
                                                    <th scope="row" colspan="7" class="text-end">Sub Total</th>
                                                    <td class="text-end"><?php echo e($stock_invoice_data->sub_total); ?>৳</td>
                                                </tr>
                                                <!-- end tr -->
                                                <tr>
                                                    <th scope="row" colspan="7" class="border-0 text-end">
                                                        Discount :</th>
                                                    <td class="border-0 text-end">- <?php echo e($stock_invoice_data->discount); ?>৳</td>
                                                </tr>
                                                <!-- end tr -->
                                                <tr>
                                                    <th scope="row" colspan="7" class="border-0 text-end">
                                                        Grand Total</th>
                                                    <td class="border-0 text-end"><?php echo e($stock_invoice_data->total); ?>৳</td>
                                                </tr>
                                                <!-- end tr -->
                                                <tr>
                                                    <th scope="row" colspan="7" class="border-0 text-end">Paid</th>
                                                    <td class="border-0 text-end"><h5 class="m-0 fw-semibold"><?php echo e($stock_invoice_data->paid); ?>৳</h5></td>
                                                </tr>
                                                <!-- end tr -->
                                                <tr>
                                                    <th scope="row" colspan="7" class="border-0 text-end">Due</th>
                                                    <td class="border-0 text-end"><h5 class="m-0 fw-semibold"><?php echo e($stock_invoice_data->due); ?>৳</h5></td>
                                                </tr>
                                                <!-- end tr -->
                                            </tbody><!-- end tbody -->
                                        </table><!-- end table -->
                                    </div><!-- end table responsive -->

                                    
                                    <div class="table-responsive px-5 mx-5">
                                        <table class="table align-middle table-nowrap table-centered mb-0">
                                            <thead>
                                                <tr class="text-center table-bordered">
                                                    <th colspan="6"><h4>Return Medicines</h4></th>
                                                </tr>
                                                <tr class="text-center">
                                                    <th>SN</th>
                                                    <th colspan="2">Medicine</th>
                                                    <th>Batch</th>
                                                    <th>Quantity</th>
                                                    <th class="text-end">Price Value</th>
                                                </tr>
                                            </thead><!-- end thead -->
                                            <tbody>
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $stock_invoice_data->stockLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $medicine_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="text-center">
                                                        <td><?php echo e($index + 1); ?></td>
                                                        <td class="text-end">
                                                            <img src="<?php echo e(asset($medicine_list->medicine->image_url ?? 'img/medicine-logo.png')); ?>" alt="" width="50">
                                                        </td>
                                                        <td class="text-start">
                                                            <div>
                                                                <h5 class="text-truncate font-size-14 mb-1"><?php echo e($medicine_list->medicine->name); ?></h5>
                                                                <p class="text-muted mb-0"><?php echo e($medicine_list->medicine->generic_name); ?></p>
                                                                <p class="text-muted mb-0"><?php echo e($medicine_list->medicine->category_name); ?></p>
                                                            </div>
                                                        </td>
                                                        <td><?php echo e($medicine_list->batch_number); ?></td>
                                                        <td><?php echo e($medicine_list->stockReturnList->sum('quantity')); ?></td>
                                                        <td class="text-end"><?php echo e($medicine_list->stockReturnList->sum('total')); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </tbody><!-- end tbody -->
                                        </table><!-- end table -->
                                    </div><!-- end table responsive -->
                                    <div class="d-print-none mt-4">
                                        <div class="float-end">
                                            <a href="javascript:window.print()" class="btn btn-success me-1"><i class="bi bi-printer"></i></a>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end col -->
                </div>
            </div>
        <?php elseif($return_invoice_data): ?>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="invoice-title">
                                    <h2>Return Medicines</h2>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-12">
                                        <form wire:submit.prevent="returnSubmit">
                                            <div class="row">
                                                <div class="col-sm-6 col-md-3">
                                                    <div class="mb-3">
                                                        <label for="return_date" class="form-label">Return Date</label>
                                                        <input type="date" class="form-control" wire:model="return_date">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['return_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-3">
                                                    <div class="mb-3">
                                                        <label for="return_medicine" class="form-label">Medicines</label>
                                                        <select name="return_medicine" id="return_medicine" class="form-select" wire:model="return_medicine">
                                                            <option value="">Select Medicine</option>
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $return_invoice_data->stockLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($medicine_list->id); ?>">
                                                                    <?php echo e($medicine_list->medicine->name); ?> (<?php echo e($medicine_list->quantity); ?>PC) - <?php echo e($site_settings->site_currency); ?> <?php echo e($medicine_list->buy_price); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </select>
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['return_medicine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-3">
                                                    <div class="mb-3">
                                                        <label for="return_quantity" class="form-label">Return Quantity</label>
                                                        <input type="number" class="form-control" wire:model="return_quantity">
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['return_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 col-md-3">
                                                    <div class="mb-3 mt-2">
                                                        <button type="submit" class="btn btn-primary btn-sm mt-4">Submit</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH H:\laragon\www\Pharmacy11\resources\views/livewire/stock-invoice-list.blade.php ENDPATH**/ ?>